# extrai anotações apenas para cavalos e cachorros substituindo as classes codificadas pelas palavras horse e dog
grep '/m/03k3r' ./datasets/train-annotations-bbox.csv | sed 's/\/m\/03k3r/horse/' > ./datasets/train-horse.csv
grep '/m/03k3r' ./datasets/val-annotations-bbox.csv | sed 's/\/m\/03k3r/horse/' > ./datasets/val-horse.csv
grep '/m/03k3r' ./datasets/test-annotations-bbox.csv | sed 's/\/m\/03k3r/horse/' > ./datasets/test-horse.csv

grep '/m/0bt9lr' ./datasets/train-annotations-bbox.csv | sed 's/\/m\/0bt9lr/dog/' > ./datasets/train-dog.csv
grep '/m/0bt9lr' ./datasets/val-annotations-bbox.csv | sed 's/\/m\/0bt9lr/dog/' > ./datasets/val-dog.csv
grep '/m/0bt9lr' ./datasets/test-annotations-bbox.csv | sed 's/\/m\/0bt9lr/dog/' > ./datasets/test-dog.csv

# concatena os arquivos de treino, validação e teste por classe para gerar o arquivo de treino, validação e teste
cat ./datasets/train-horse.csv ./datasets/train-dog.csv > ./datasets/train.csv
cat ./datasets/val-horse.csv ./datasets/val-dog.csv > ./datasets/val.csv
cat ./datasets/test-horse.csv ./datasets/test-dog.csv > ./datasets/test.csv

# remove os arquivos temporários
rm ./datasets/train-horse.csv ./datasets/train-dog.csv ./datasets/val-horse.csv ./datasets/val-dog.csv ./datasets/test-horse.csv ./datasets/test-dog.csv

# um arquivo com todas as imagens (all_images.txt) para usar como entrada para o programa de download das imagens 
# baixado do site Open Images
cat ./datasets/train.csv |  cut -d "," -f1 | awk -F/ 'NF>0{$0 = "train" FS $0}1' |sort | uniq -u > ./datasets/train_images.txt
cat ./datasets/val.csv |  cut -d "," -f1 | awk -F/ 'NF>0{$0 = "validation" FS $0}1' |sort | uniq -u > ./datasets/val_images.txt
cat ./datasets/test.csv |  cut -d "," -f1 | awk -F/ 'NF>0{$0 = "test" FS $0}1' |sort | uniq -u > ./datasets/test_images.txt

cat ./datasets/train_images.txt ./datasets/val_images.txt ./datasets/test_images.txt > ./datasets/all_images.txt

rm ./datasets/train_images.txt ./datasets/val_images.txt ./datasets/test_images.txt
