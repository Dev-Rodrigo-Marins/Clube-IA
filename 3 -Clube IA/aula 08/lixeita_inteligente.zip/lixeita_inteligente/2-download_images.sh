python3 downloader.py ./datasets/all_images.txt --download_folder=./datasets/images --num_processes=5
