import pandas as pd
import os
import shutil as sh

# Cabeçalho para carregar os csvs de anotação para os dataframes
csv_column_names = ["ImageID","Source","LabelName","Confidence","XMin","XMax","YMin","YMax","IsOccluded","IsTruncated","IsGroupOf","IsDepiction","IsInside","XClick1X","XClick2X","XClick3X","XClick4X","XClick1Y","XClick2Y","XClick3Y","XClick4Y"]

# Criar dicionario das classes com base no classes.txt
classes = {}
with open("classes.txt", "r") as myFile:
    for num, line in enumerate(myFile, 0):
        line = line.rstrip("\n")
        classes[line] = num
    myFile.close()

# Carrrega os 3 dataframes salvando num dicionario de dataframes para pode iterar
train_df = pd.read_csv('./datasets/train.csv', names=csv_column_names)
val_df = pd.read_csv('./datasets/val.csv', names=csv_column_names)
test_df = pd.read_csv('./datasets/test.csv', names=csv_column_names)

dfs = {"train": train_df, "val": val_df, "test": test_df}

i = 0

# Itera sobre os arquivos 
for subset in ["train", "val", "test"]:
    # Itera sobre as anotações
    for idx, row1 in dfs[subset].iterrows():
        image_id = row1["ImageID"]
        image_path = os.path.join("./datasets/images", image_id + ".jpg") # caminho da imagem baixada
        dest_path = os.path.join("./datasets/yolo_input", subset, image_id + ".jpg") # caminho para yolo input

        # Ignora imagens já processadas
        if not os.path.exists(image_path) or os.path.exists(dest_path):
            continue

        # Copia imagem para o diretório yolo_input/{subset}
        sh.copy(image_path, dest_path)

        # Cria um arquivo de anotação para cada imagem no diretónrio yolo_input/{subset}
        with open(os.path.join("./datasets/yolo_input", subset, image_id + ".txt"), "w") as f:
            for idx, row in (dfs[subset][dfs[subset]["ImageID"]==image_id]).iterrows():
                # Converte de open image para padrão de input do yolo
                x = row["XMin"] + round((row["XMax"] - row["XMin"])/2,9)
                y = row["YMin"] + round((row["YMax"] - row["YMin"])/2,9)
                largura = (row["XMax"] - row["XMin"])
                altura = (row["YMax"] - row["YMin"])
                f.write(str(classes[row["LabelName"]]) + " " + str(x) + " " + str(y) + " " + str(largura) + " " + str(altura) + "\n")
            f.close()
